import '../App.css';


export default function Welcome() {

    return (
        <>
            <style>{"table{border:1px solid black;}"}
            </style>
            <div className="container">
                <h2 className="my-4"> Welcome to So Many Activities! </h2>
                <p>So you've found us. Great, the next step is to log in to join millions of users in the group</p>
            </div>
        </>
    );

}
